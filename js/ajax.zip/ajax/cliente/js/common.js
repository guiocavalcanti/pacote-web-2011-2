// O .ready espera a DOM, JS e imagens carregarem

$(document).ready(function(){
});
